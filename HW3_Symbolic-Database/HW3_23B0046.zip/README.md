## Tensor product pemutation checker.

Note, the github repo can be found here: [https://github.com/Sam-MARTis/AE6104](https://github.com/Sam-MARTis/AE6104)
Simplifiies opeators of the form 
(A op B)(C op D)

op can be any of the five tensor product and A B C D are second order tensors(not necessarily different).

The program takes in a sting that is an identifier made from the indices of the operators and Tensors. 

The detiled instructions to use the program with examples are in `TensorDatabase.py`.

For solution to q2 in hw3 of AE6104, refer to `q3.py`